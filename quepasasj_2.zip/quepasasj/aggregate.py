"""
Qué Pasa SJ — Daily event aggregator
Runs every day via GitHub Actions, fetches events from 5 sources,
deduplicates, and writes events.json that the website loads.
"""
import json
import sys
from datetime import datetime, timezone, timedelta
from pathlib import Path

from scrapers.bandsintown import scrape_bandsintown
from scrapers.eventbrite import scrape_eventbrite
from scrapers.discover_pr import scrape_discover_pr
from scrapers.resident_advisor import scrape_resident_advisor
from scrapers.songkick import scrape_songkick


def dedupe(events):
    """Remove duplicate events across sources by (artist + date) match."""
    seen = {}
    for e in events:
        # Key combines artist name (lowercased) + date
        key = (e.get("artist", "").lower().strip()[:40], e.get("date", "")[:10])
        if key not in seen:
            seen[key] = e
        else:
            # Prefer the one with a ticket URL
            if not seen[key].get("url") and e.get("url"):
                seen[key] = e
    return list(seen.values())


def filter_upcoming(events):
    """Drop past events (older than today in PR time)."""
    pr_now = datetime.now(timezone(timedelta(hours=-4)))
    cutoff = pr_now.replace(hour=0, minute=0, second=0, microsecond=0)
    keep = []
    for e in events:
        try:
            event_dt = datetime.fromisoformat(e["date"].replace("Z", "+00:00"))
            if event_dt.tzinfo is None:
                event_dt = event_dt.replace(tzinfo=timezone(timedelta(hours=-4)))
            if event_dt >= cutoff:
                keep.append(e)
        except (ValueError, KeyError):
            # If date is unparseable, keep it (better to over-include than drop)
            keep.append(e)
    return keep


def main():
    print("=" * 60)
    print(f"Qué Pasa SJ aggregator — {datetime.utcnow().isoformat()}Z")
    print("=" * 60)

    all_events = []
    sources = [
        ("Bandsintown", scrape_bandsintown),
        ("Eventbrite", scrape_eventbrite),
        ("Discover PR", scrape_discover_pr),
        ("Resident Advisor", scrape_resident_advisor),
        ("Songkick", scrape_songkick),
    ]

    for name, scraper in sources:
        print(f"\n→ {name}...")
        try:
            events = scraper()
            print(f"  ✓ {len(events)} events")
            all_events.extend(events)
        except Exception as exc:
            # One source failing should never kill the whole run
            print(f"  ✗ FAILED: {exc}", file=sys.stderr)

    print(f"\n→ Total raw: {len(all_events)}")
    upcoming = filter_upcoming(all_events)
    print(f"→ After dropping past events: {len(upcoming)}")
    deduped = dedupe(upcoming)
    print(f"→ After dedupe: {len(deduped)}")

    # Sort by date ascending
    deduped.sort(key=lambda e: e.get("date", "9999"))

    payload = {
        "generated_at": datetime.utcnow().isoformat() + "Z",
        "count": len(deduped),
        "events": deduped,
    }

    out_path = Path(__file__).parent / "events.json"
    out_path.write_text(json.dumps(payload, indent=2, ensure_ascii=False))
    print(f"\n✓ Wrote {out_path} ({len(deduped)} events)")


if __name__ == "__main__":
    main()

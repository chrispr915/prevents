"""
ScraperAPI wrapper.

If SCRAPERAPI_KEY is set in the environment, requests are routed through
ScraperAPI (which handles rotating proxies and anti-bot bypass). If not,
falls back to direct requests (useful for local testing).
"""
import os
import requests

DEFAULT_HEADERS = {
    "User-Agent": "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) "
                  "AppleWebKit/537.36 (KHTML, like Gecko) "
                  "Chrome/120.0.0.0 Safari/537.36",
    "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
    "Accept-Language": "en-US,en;q=0.9",
}

SCRAPERAPI_ENDPOINT = "https://api.scraperapi.com/"


def fetch(url, timeout=45, render=False):
    """
    Fetch a URL, optionally through ScraperAPI.

    Args:
        url: target URL
        timeout: seconds before giving up
        render: if True, asks ScraperAPI to run JavaScript (costs 10 credits
                instead of 1; use only for JS-heavy sites that need it)
    """
    key = os.environ.get("SCRAPERAPI_KEY")

    if key:
        params = {
            "api_key": key,
            "url": url,
            "country_code": "us",  # PR-friendly geo
        }
        if render:
            params["render"] = "true"
        resp = requests.get(SCRAPERAPI_ENDPOINT, params=params,
                            timeout=timeout)
    else:
        # No key — direct request. Will likely 403 from cloud IPs but works locally.
        resp = requests.get(url, headers=DEFAULT_HEADERS, timeout=timeout)

    resp.raise_for_status()
    return resp.text

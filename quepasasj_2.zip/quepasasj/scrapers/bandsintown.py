"""Bandsintown — public San Juan city page."""
import json
import re

from ._proxy import fetch

URL = "https://www.bandsintown.com/c/san-juan-puerto-rico"


def scrape_bandsintown():
    html = fetch(URL)

    events = []
    # Try the embedded state blob first
    match = re.search(r'window\.__INITIAL_STATE__\s*=\s*(\{.*?\});', html, re.DOTALL)
    if match:
        try:
            state = json.loads(match.group(1))
            _walk(state, events)
        except json.JSONDecodeError:
            pass

    # Try JSON-LD
    if not events:
        for m in re.finditer(
            r'<script type="application/ld\+json">(.*?)</script>',
            html, re.DOTALL
        ):
            try:
                data = json.loads(m.group(1))
                _walk_jsonld(data, events)
            except json.JSONDecodeError:
                continue

    return events


def _walk(obj, bucket):
    if isinstance(obj, dict):
        has_date = any(k in obj for k in ("datetime", "starts_at", "date", "startDate"))
        has_venue = "venue" in obj or "venue_name" in obj
        has_artist = "artist" in obj or "lineup" in obj or "title" in obj or "name" in obj
        if has_date and (has_venue or has_artist):
            normalized = _normalize(obj)
            if normalized:
                bucket.append(normalized)
        for v in obj.values():
            _walk(v, bucket)
    elif isinstance(obj, list):
        for item in obj:
            _walk(item, bucket)


def _walk_jsonld(obj, bucket):
    if isinstance(obj, dict):
        if "Event" in str(obj.get("@type", "")) and obj.get("name"):
            location = obj.get("location", {})
            if isinstance(location, list):
                location = location[0] if location else {}
            venue = location.get("name", "TBA") if isinstance(location, dict) else "TBA"
            img = obj.get("image", "")
            if isinstance(img, list):
                img = img[0] if img else ""
            if isinstance(img, dict):
                img = img.get("url", "")
            bucket.append({
                "artist": obj.get("name", ""),
                "venue": venue,
                "date": obj.get("startDate", ""),
                "genre": _guess_genre(obj.get("name", "")),
                "url": obj.get("url", URL),
                "image": img if isinstance(img, str) else "",
                "source": "Bandsintown",
            })
        for v in obj.values():
            _walk_jsonld(v, bucket)
    elif isinstance(obj, list):
        for item in obj:
            _walk_jsonld(item, bucket)


def _normalize(raw):
    artist = raw.get("title") or raw.get("name", "")
    if not artist and isinstance(raw.get("artist"), dict):
        artist = raw["artist"].get("name", "")
    elif isinstance(raw.get("artist"), str):
        artist = raw["artist"]

    if not artist:
        return None

    venue = raw.get("venue", {})
    if isinstance(venue, dict):
        venue_name = venue.get("name", raw.get("venue_name", "TBA"))
    else:
        venue_name = raw.get("venue_name", "TBA")

    date = raw.get("datetime") or raw.get("starts_at") or raw.get("date") or raw.get("startDate", "")

    return {
        "artist": str(artist)[:120],
        "venue": str(venue_name)[:120],
        "date": str(date),
        "genre": _guess_genre(str(artist)),
        "url": raw.get("url") or raw.get("ticket_url") or URL,
        "image": raw.get("image", "") if isinstance(raw.get("image"), str) else "",
        "source": "Bandsintown",
    }


def _guess_genre(name):
    name = name.lower()
    if any(w in name for w in ["dj ", " dj", "fest", "edm", "electronic",
                                "techno", "house", "rave"]):
        return "electronic"
    if any(w in name for w in ["jazz", "trio", "quartet", "ensemble", "bolero"]):
        return "jazz"
    if any(w in name for w in ["metal", "death", "thrash", "doom", "core"]):
        return "metal"
    if any(w in name for w in ["salsa", "reggaeton", "bachata", "merengue",
                                "bomba", "plena"]):
        return "latin"
    if any(w in name for w in ["comedy", "comedian", "stand-up", "lopez"]):
        return "comedy"
    return "music"

"""Discover Puerto Rico — official tourism board events calendar."""
import json
import re

from ._proxy import fetch

URL = "https://www.discoverpuertorico.com/events"


def scrape_discover_pr():
    html = fetch(URL)
    events = []

    for match in re.finditer(
        r'<script type="application/ld\+json">(.*?)</script>',
        html, re.DOTALL
    ):
        try:
            data = json.loads(match.group(1))
            _harvest(data, events)
        except json.JSONDecodeError:
            continue

    return [_normalize(e) for e in events if _looks_event(e)]


def _harvest(obj, bucket):
    if isinstance(obj, dict):
        t = obj.get("@type", "")
        types = t if isinstance(t, list) else [t]
        if any("Event" in str(x) for x in types):
            bucket.append(obj)
        for v in obj.values():
            _harvest(v, bucket)
    elif isinstance(obj, list):
        for item in obj:
            _harvest(item, bucket)


def _looks_event(e):
    return e.get("name") and (e.get("startDate") or e.get("start_date"))


def _normalize(e):
    location = e.get("location", {})
    if isinstance(location, list):
        location = location[0] if location else {}
    venue_name = (location.get("name", "TBA") if isinstance(location, dict)
                  else "TBA")

    image = ""
    img = e.get("image", "")
    if isinstance(img, str):
        image = img
    elif isinstance(img, list) and img:
        first = img[0]
        image = first if isinstance(first, str) else (
            first.get("url", "") if isinstance(first, dict) else ""
        )
    elif isinstance(img, dict):
        image = img.get("url", "")

    return {
        "artist": str(e.get("name", "Untitled"))[:120],
        "venue": str(venue_name)[:120],
        "date": str(e.get("startDate", "")),
        "genre": "festival",
        "url": e.get("url", URL),
        "image": image,
        "source": "Discover PR",
    }

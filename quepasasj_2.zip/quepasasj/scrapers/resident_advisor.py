"""Resident Advisor — electronic / club events for Puerto Rico."""
import json
import re

from ._proxy import fetch

URL = "https://ra.co/events/pr"


def scrape_resident_advisor():
    html = fetch(URL, render=True)  # RA is JS-heavy, needs rendering
    events = []

    # Try Next.js data first
    match = re.search(
        r'<script id="__NEXT_DATA__" type="application/json">(.*?)</script>',
        html, re.DOTALL
    )
    if match:
        try:
            data = json.loads(match.group(1))
            _walk(data, events)
        except json.JSONDecodeError:
            pass

    # Fallback to JSON-LD
    if not events:
        for m in re.finditer(
            r'<script type="application/ld\+json">(.*?)</script>',
            html, re.DOTALL
        ):
            try:
                data = json.loads(m.group(1))
                _walk_jsonld(data, events)
            except json.JSONDecodeError:
                continue

    return events


def _walk(obj, bucket):
    if isinstance(obj, dict):
        if obj.get("__typename") == "Event" and obj.get("title"):
            bucket.append(_normalize_ra(obj))
        for v in obj.values():
            _walk(v, bucket)
    elif isinstance(obj, list):
        for item in obj:
            _walk(item, bucket)


def _walk_jsonld(obj, bucket):
    if isinstance(obj, dict):
        if "Event" in str(obj.get("@type", "")) and obj.get("name"):
            location = obj.get("location", {})
            if isinstance(location, list):
                location = location[0] if location else {}
            venue = (location.get("name", "TBA") if isinstance(location, dict)
                     else "TBA")
            img = obj.get("image", "")
            if isinstance(img, list):
                img = img[0] if img else ""
            bucket.append({
                "artist": str(obj.get("name", ""))[:120],
                "venue": str(venue)[:120],
                "date": str(obj.get("startDate", "")),
                "genre": "electronic",
                "url": obj.get("url", URL),
                "image": img if isinstance(img, str) else "",
                "source": "Resident Advisor",
            })
        for v in obj.values():
            _walk_jsonld(v, bucket)
    elif isinstance(obj, list):
        for item in obj:
            _walk_jsonld(item, bucket)


def _normalize_ra(raw):
    venue = raw.get("venue") or {}
    venue_name = (venue.get("name", "TBA") if isinstance(venue, dict)
                  else "TBA")

    images = raw.get("images") or raw.get("flyerFront") or []
    image = ""
    if isinstance(images, list) and images:
        first = images[0]
        image = (first.get("filename", "") if isinstance(first, dict)
                 else str(first))
    elif isinstance(images, str):
        image = images

    content_url = raw.get("contentUrl") or raw.get("slug") or ""
    if content_url and not content_url.startswith("http"):
        content_url = "https://ra.co" + (
            content_url if content_url.startswith("/") else "/" + content_url
        )

    return {
        "artist": str(raw.get("title", "Untitled"))[:120],
        "venue": str(venue_name)[:120],
        "date": str(raw.get("date") or raw.get("startTime", "")),
        "genre": "electronic",
        "url": content_url or URL,
        "image": image,
        "source": "Resident Advisor",
    }

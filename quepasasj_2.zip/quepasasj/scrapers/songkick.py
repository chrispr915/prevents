"""Songkick — San Juan metro area concerts."""
import json
import re

from ._proxy import fetch

URL = "https://www.songkick.com/metro-areas/34661-puerto-rico-san-juan"


def scrape_songkick():
    html = fetch(URL)
    events = []

    for match in re.finditer(
        r'<script type="application/ld\+json">(.*?)</script>',
        html, re.DOTALL
    ):
        try:
            data = json.loads(match.group(1))
            _harvest(data, events)
        except json.JSONDecodeError:
            continue

    return [_normalize(e) for e in events if _is_event(e)]


def _harvest(obj, bucket):
    if isinstance(obj, dict):
        if "Event" in str(obj.get("@type", "")) and obj.get("name"):
            bucket.append(obj)
        for v in obj.values():
            _harvest(v, bucket)
    elif isinstance(obj, list):
        for item in obj:
            _harvest(item, bucket)


def _is_event(e):
    return e.get("name") and e.get("startDate")


def _normalize(e):
    location = e.get("location", {})
    if isinstance(location, list):
        location = location[0] if location else {}
    venue_name = (location.get("name", "TBA") if isinstance(location, dict)
                  else "TBA")

    image = ""
    img = e.get("image")
    if isinstance(img, str):
        image = img
    elif isinstance(img, list) and img:
        image = img[0] if isinstance(img[0], str) else ""

    return {
        "artist": str(e.get("name", "Untitled"))[:120],
        "venue": str(venue_name)[:120],
        "date": str(e.get("startDate", "")),
        "genre": "music",
        "url": e.get("url", URL),
        "image": image,
        "source": "Songkick",
    }

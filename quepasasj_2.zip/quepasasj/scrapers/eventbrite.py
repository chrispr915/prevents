"""Eventbrite — public San Juan event search."""
import json
import re

from ._proxy import fetch

URL = "https://www.eventbrite.com/d/puerto-rico--san-juan/events/"


def scrape_eventbrite():
    html = fetch(URL)
    events = []

    # Eventbrite injects search results into __SERVER_DATA__
    match = re.search(r'window\.__SERVER_DATA__\s*=\s*(\{.*?\});\s*</script>',
                      html, re.DOTALL)
    if match:
        try:
            data = json.loads(match.group(1))
            _collect(data, events)
        except json.JSONDecodeError:
            pass

    return [_normalize(e) for e in events if _is_pr(e)]


def _collect(obj, bucket):
    if isinstance(obj, dict):
        if (obj.get("name") and
            (obj.get("start_date") or obj.get("start")) and
            obj.get("url")):
            bucket.append(obj)
        for v in obj.values():
            _collect(v, bucket)
    elif isinstance(obj, list):
        for item in obj:
            _collect(item, bucket)


def _is_pr(e):
    venue = e.get("primary_venue") or e.get("venue") or {}
    if not isinstance(venue, dict):
        return False
    addr = venue.get("address", {})
    region = (addr.get("region") or addr.get("country") or "").upper()
    city = (addr.get("city") or "").lower()
    if "PR" in region or "PUERTO RICO" in region:
        return True
    return any(c in city for c in ["san juan", "santurce", "condado",
                                    "miramar", "carolina", "guaynabo",
                                    "isla verde", "rio piedras"])


def _normalize(e):
    venue = e.get("primary_venue") or e.get("venue") or {}
    venue_name = venue.get("name", "TBA") if isinstance(venue, dict) else "TBA"

    start = e.get("start_date") or (
        e.get("start", {}).get("local") if isinstance(e.get("start"), dict) else ""
    )

    img = e.get("image", {})
    image_url = ""
    if isinstance(img, dict):
        image_url = img.get("url", "") or (img.get("original", {}).get("url", "")
                    if isinstance(img.get("original"), dict) else "")

    return {
        "artist": str(e.get("name", "Untitled event"))[:120],
        "venue": str(venue_name)[:120],
        "date": str(start),
        "genre": _category(e),
        "url": e.get("url", ""),
        "image": image_url,
        "source": "Eventbrite",
    }


def _category(e):
    cat_obj = e.get("category")
    cat = ""
    if isinstance(cat_obj, dict):
        cat = cat_obj.get("name", "").lower()
    elif isinstance(cat_obj, str):
        cat = cat_obj.lower()

    if "music" in cat or "concert" in cat: return "music"
    if "food" in cat or "drink" in cat: return "food"
    if "art" in cat: return "arts"
    if "business" in cat or "tech" in cat: return "business"
    if "sport" in cat or "fitness" in cat: return "sports"
    if "comedy" in cat: return "comedy"
    if "film" in cat: return "film"
    return "community"

# Qué Pasa SJ — Auto-Updating San Juan Events

Live event aggregator. Runs daily on GitHub Actions (free), pulls events from
5 sources via ScraperAPI, displays them on a static page hosted on GitHub Pages
(also free).

**Total cost: $0/month.** ($10/year if you buy a custom domain — optional.)

---

## What you're setting up

```
┌─────────────────────────────────────────────────────────┐
│  Every day at 6 AM AST:                                 │
│                                                          │
│  GitHub Actions wakes up → runs aggregate.py            │
│       ↓                                                  │
│  Python script calls 5 scrapers (via ScraperAPI proxy)  │
│       ↓                                                  │
│  Scrapers pull events from Bandsintown, Eventbrite,     │
│       Discover PR, Resident Advisor, Songkick           │
│       ↓                                                  │
│  Events deduped, sorted, written to events.json         │
│       ↓                                                  │
│  GitHub auto-commits the new events.json                │
│                                                          │
│  Anyone visiting your page sees fresh events.           │
└─────────────────────────────────────────────────────────┘
```

---

## Setup (one time, ~20 minutes)

### 1. Make a free GitHub account

Go to **github.com/signup**. Use any email. Pick a username — this becomes
part of your site URL (e.g. `username.github.io/quepasasj`).

### 2. Make a free ScraperAPI account

Go to **scraperapi.com/signup**. Email + password, no card needed.

After signup, go to your **Dashboard** → copy your **API Key**. Looks like a
random string of letters and numbers. Keep this tab open.

### 3. Create the GitHub repo

1. On github.com, click the **+** in the top right → **New repository**
2. Name it: `quepasasj` (lowercase)
3. Set it to **Public** (required for free GitHub Pages and Actions)
4. Do **NOT** check "Add a README" — we have one
5. Click **Create repository**

### 4. Upload these files to the repo

GitHub will show you an empty repo page. Click **"uploading an existing file"**
in the quick-setup section.

Drag in **all the files and folders from this project**:
- `index.html`
- `events.json`
- `aggregate.py`
- `requirements.txt`
- `README.md`
- `scrapers/` folder (the whole folder)
- `.github/` folder (the whole folder — important!)

If GitHub's web UI doesn't let you drag folders, you'll need to:
1. Drag the loose files first, commit
2. Then for each folder, click **Add file → Create new file**, type the path
   (e.g. `scrapers/bandsintown.py`), paste contents, commit

Easier option: install **GitHub Desktop** (free, github.com/desktop), drag the
whole folder in once.

When done, your repo should look like:
```
quepasasj/
├── .github/
│   └── workflows/
│       └── refresh.yml
├── scrapers/
│   ├── __init__.py
│   ├── _proxy.py
│   ├── bandsintown.py
│   ├── eventbrite.py
│   ├── discover_pr.py
│   ├── resident_advisor.py
│   └── songkick.py
├── aggregate.py
├── events.json
├── index.html
├── requirements.txt
└── README.md
```

### 5. Add your ScraperAPI key as a GitHub secret

In your repo:
1. Click **Settings** (top right of repo nav)
2. Left sidebar: **Secrets and variables** → **Actions**
3. Click **New repository secret**
4. **Name:** `SCRAPERAPI_KEY` (exactly this, all caps)
5. **Secret:** paste your ScraperAPI key
6. Click **Add secret**

This is the secure way — your key is encrypted, never visible in code, and
only the GitHub Actions runner can read it.

### 6. Turn on GitHub Pages

In your repo:
1. **Settings** → left sidebar **Pages**
2. Under **Source**, choose **Deploy from a branch**
3. Branch: **main**, folder: **/ (root)**
4. Click **Save**

Wait ~1 minute. Refresh the Pages settings page. You'll see:
> Your site is live at **https://YOUR-USERNAME.github.io/quepasasj/**

That's your URL. Bookmark it. **This goes in your Instagram bio.**

### 7. Trigger the first run

Don't wait until 6 AM tomorrow — run it now to test.

1. In your repo, click the **Actions** tab
2. On the left, click **Daily event refresh**
3. On the right, click **Run workflow** → **Run workflow**
4. Wait ~1 minute, refresh the page
5. You should see a green checkmark ✓

If it failed (red X), click into the run, expand the failed step, and look at
the error. Most common: misspelled the secret name (must be `SCRAPERAPI_KEY`).

### 8. Confirm it works

After the green checkmark, your repo should have an updated `events.json`
with real data. Visit your URL — events should appear inline.

---

## Daily operation

**You do nothing.** Every morning at 6 AM AST (10 AM UTC), GitHub Actions
runs the aggregator. New events appear on your site automatically.

---

## When something breaks

Sites change their HTML occasionally, which breaks scrapers. You'll notice
when:
- The site shows fewer events than expected
- The Actions tab has a red X on a recent run

**To diagnose:**
1. Click the failed run in **Actions**
2. Look at the log — it'll say which scraper failed
3. Either ask Claude to fix that one scraper, or wait for the next time
   they change something

The aggregator is designed so **one broken scraper doesn't kill the others**.
You'll still get partial data even when one source is down.

---

## Customization

**Change the schedule:**
Edit `.github/workflows/refresh.yml`. The line `cron: '0 10 * * *'` runs at
10 AM UTC daily. To run more often (e.g., every 6 hours), use `0 */6 * * *`.
Don't go more frequent than every 4 hours — wastes ScraperAPI credits.

**Add a new source:**
Create a file in `scrapers/`, copy the structure of an existing scraper,
add it to the `sources` list in `aggregate.py`. Tell Claude what site you
want and they'll write the scraper.

**Custom domain (optional, $10/year):**
Buy a domain at **porkbun.com** or **cloudflare.com**. Then in your repo's
**Settings → Pages**, add the custom domain. GitHub has step-by-step DNS
instructions on that page.

---

## Free tier limits (FYI, you won't hit these)

- **ScraperAPI free:** 1,000 requests/month. We use ~150.
- **GitHub Actions free:** unlimited for public repos.
- **GitHub Pages free:** 100 GB bandwidth/month. You'd need ~50,000 visitors
  to hit this.

---

## File list

| File | What it does |
|------|--------------|
| `index.html` | The website itself. Loads `events.json` and shows events. |
| `events.json` | Auto-generated. The list of upcoming events. |
| `aggregate.py` | Calls all scrapers, dedupes, writes `events.json`. |
| `scrapers/_proxy.py` | Wrapper that routes requests through ScraperAPI. |
| `scrapers/*.py` | One per source — pulls events and normalizes them. |
| `.github/workflows/refresh.yml` | Schedules the daily run on GitHub Actions. |
| `requirements.txt` | Python dependencies (just `requests`). |

---

Built with help from Claude.
